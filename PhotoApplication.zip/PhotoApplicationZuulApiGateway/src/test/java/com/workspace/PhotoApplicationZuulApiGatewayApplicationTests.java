package com.workspace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoApplicationZuulApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
