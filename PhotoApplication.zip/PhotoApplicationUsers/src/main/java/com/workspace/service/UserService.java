package com.workspace.service;

import com.workspace.shared.UserDto;

public interface UserService {
	
	UserDto createUser(UserDto usrdto);

}
